
if [ -f "/data/data/com.termux/files/usr/bin/akhub" ];
then
  rm /data/data/com.termux/files/usr/bin/akhub
fi
if [ -f "/data/data/com.termux/files/usr/bin/uninstall-akhub" ];
then
  rm /data/data/com.termux/files/usr/bin/uninstall-akhub
fi
  
  cp /data/data/com.termux/files/usr/share/akhub/share/akhub /data/data/com.termux/files/usr/bin/
  cp /data/data/com.termux/files/usr/share/akhub/share/uninstall-akhub /data/data/com.termux/files/usr/bin/
  chmod +x /data/data/com.termux/files/usr/bin/akhub
  chmod +x /data/data/com.termux/files/usr/bin/uninstall-akhub


cp /data/data/com.termux/files/usr/share/akhub/share/figlet-fonts/* /data/data/com.termux/files/usr/share/share/figlet/

if [ -f "/data/data/com.termux/files/usr/bin/login" ];
then
  rm /data/data/com.termux/files/usr/bin/login
fi
cp /data/data/com.termux/files/usr/share/akhub/share/login /data/data/com.termux/files/usr/bin/
chmod +x $PREFIX/bin/login
if [ -f "$PREFIX/etc/motd" ];
then
  rm $PREFIX/etc/motd
fi
cp /data/data/com.termux/files/usr/share/akhub/share/motd /data/data/com.termux/files/usr/etc/
chmod +x $PREFIX/etc/motd
